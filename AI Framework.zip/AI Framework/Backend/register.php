<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';

$user = authenticated_user();
if ($user !== null) {
	$destination = ($user['role'] ?? '') === 'admin' ? 'Backend/admin/dashboard.php' : 'index.php';
	header('Location: ' . app_url($destination));
	exit;
}

$error = '';
$fullName = trim((string) ($_POST['full_name'] ?? ''));
$email = strtolower(trim((string) ($_POST['email'] ?? '')));

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
	$password = (string) ($_POST['password'] ?? '');
	$confirmation = (string) ($_POST['password_confirmation'] ?? '');
	$nameLength = function_exists('mb_strlen') ? mb_strlen($fullName, 'UTF-8') : strlen($fullName);

	if (!verify_csrf_token($_POST['csrf_token'] ?? null)) {
		$error = 'Your session expired. Refresh this page and try again.';
	} elseif ($nameLength < 2 || $nameLength > 120) {
		$error = 'Enter your name using 2 to 120 characters.';
	} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
		$error = 'Enter a valid email address.';
	} elseif (strlen($password) < 12) {
		$error = 'Choose a password with at least 12 characters.';
	} elseif ($password !== $confirmation) {
		$error = 'The passwords do not match.';
	} else {
		try {
			$insert = database()->prepare(
				'INSERT INTO users (full_name, email, password_hash, role)
				 VALUES (:full_name, :email, :password_hash, \'student\')'
			);
			$insert->execute([
				'full_name' => $fullName,
				'email' => $email,
				'password_hash' => password_hash($password, PASSWORD_DEFAULT),
			]);
			$_SESSION['auth_flash'] = 'Your account is ready. Sign in to continue.';
			header('Location: ' . app_url('Backend/login.php'));
			exit;
		} catch (PDOException $exception) {
			if ($exception->getCode() === '23000') {
				$error = 'An account already uses this email address.';
			} else {
				database_error();
			}
		}
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="theme-color" content="#f6f7f2">
	<title>Create account | Learnwise</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="<?= escape_html(app_url('CSS/auth.css')) ?>">
</head>
<body>
	<main class="auth-shell">
		<section class="auth-aside" aria-label="Learnwise student learning platform">
			<a class="auth-brand" href="<?= escape_html(app_url('')) ?>"><span class="brand-mark">L</span><span>learnwise<span class="brand-dot">.</span></span></a>
			<div class="aside-message"><span class="aside-kicker">A STUDY SPACE THAT FITS YOU</span><h1>Make your learning count.</h1><p>Track study sessions, notice your habits and find a good next step.</p></div>
			<div class="aside-foot"><span>YOUR LEARNING, YOUR PACE</span><span class="aside-mark">✳</span></div>
		</section>
		<section class="auth-main">
			<div class="auth-form-wrap">
				<p class="auth-eyebrow">GET STARTED</p>
				<h2>Create your account</h2>
				<p class="auth-description">Set up your student learning space.</p>
				<?php if ($error !== ''): ?><div class="auth-alert auth-error" role="alert"><?= escape_html($error) ?></div><?php endif; ?>
				<form method="post" action="<?= escape_html(app_url('Backend/register.php')) ?>" class="auth-form">
					<input type="hidden" name="csrf_token" value="<?= escape_html(csrf_token()) ?>">
					<label for="full-name">Full name</label>
					<input id="full-name" name="full_name" type="text" autocomplete="name" minlength="2" maxlength="120" value="<?= escape_html($fullName) ?>" required>
					<label for="email">Email address</label>
					<input id="email" name="email" type="email" autocomplete="email" maxlength="190" value="<?= escape_html($email) ?>" required>
					<label for="password">Password <span class="label-hint">12 characters minimum</span></label>
					<input id="password" name="password" type="password" autocomplete="new-password" minlength="12" required>
					<label for="password-confirmation">Confirm password</label>
					<input id="password-confirmation" name="password_confirmation" type="password" autocomplete="new-password" minlength="12" required>
					<button class="auth-submit" type="submit">Create student account <span aria-hidden="true">→</span></button>
				</form>
				<p class="auth-switch">Already registered? <a href="<?= escape_html(app_url('Backend/login.php')) ?>">Sign in</a></p>
			</div>
		</section>
	</main>
</body>
</html>
