<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';

$user = require_authenticated_user(true);
if (($user['role'] ?? '') !== 'student') {
	send_json(['error' => 'This endpoint is available to student accounts only.'], 403);
}
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$ownerKey = current_owner_key();

try {
	$pdo = database();

	if ($method === 'GET') {
		$sessionsQuery = $pdo->prepare(
			'SELECT id, subject, duration_minutes, focus_level, note, studied_at
			 FROM study_sessions
			 WHERE owner_key = :owner_key
			 ORDER BY studied_at DESC, id DESC
			 LIMIT 100'
		);
		$sessionsQuery->execute(['owner_key' => $ownerKey]);
		$sessions = $sessionsQuery->fetchAll();

		$now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
		$weekStart = $now->modify('monday this week')->setTime(0, 0);
		$weekEnd = $weekStart->modify('+7 days');
		$weekQuery = $pdo->prepare(
			'SELECT subject, duration_minutes, studied_at
			 FROM study_sessions
			 WHERE owner_key = :owner_key AND studied_at >= :week_start AND studied_at < :week_end'
		);
		$weekQuery->execute([
			'owner_key' => $ownerKey,
			'week_start' => $weekStart->format('Y-m-d H:i:s'),
			'week_end' => $weekEnd->format('Y-m-d H:i:s'),
		]);
		$weekSessions = $weekQuery->fetchAll();

		$dayMinutes = array_fill(0, 7, 0);
		$subjects = [];
		$weeklyMinutes = 0;
		foreach ($weekSessions as $session) {
			$minutes = (int) $session['duration_minutes'];
			$weeklyMinutes += $minutes;
			$dayIndex = (int) (new DateTimeImmutable($session['studied_at'], new DateTimeZone('UTC')))->format('N') - 1;
			$dayMinutes[$dayIndex] += $minutes;

			$subject = $session['subject'];
			if (!isset($subjects[$subject])) {
				$subjects[$subject] = 0;
			}
			$subjects[$subject] += $minutes;
		}

		arsort($subjects);
		$subjectSummary = [];
		foreach ($subjects as $subject => $minutes) {
			$subjectSummary[] = ['subject' => $subject, 'minutes' => $minutes];
		}

		$aggregateQuery = $pdo->prepare(
			'SELECT COUNT(*) AS session_count, AVG(focus_level) AS average_focus
			 FROM study_sessions WHERE owner_key = :owner_key'
		);
		$aggregateQuery->execute(['owner_key' => $ownerKey]);
		$aggregate = $aggregateQuery->fetch();

		$dateQuery = $pdo->prepare(
			'SELECT DISTINCT DATE(studied_at) AS study_date
			 FROM study_sessions
			 WHERE owner_key = :owner_key AND studied_at >= :date_floor
			 ORDER BY study_date DESC'
		);
		$dateQuery->execute([
			'owner_key' => $ownerKey,
			'date_floor' => $now->modify('-60 days')->setTime(0, 0)->format('Y-m-d H:i:s'),
		]);
		$studyDates = array_column($dateQuery->fetchAll(), 'study_date');
		$dateSet = array_fill_keys($studyDates, true);
		$streak = 0;
		$streakDate = $now->format('Y-m-d');
		if (!isset($dateSet[$streakDate])) {
			$streakDate = $now->modify('-1 day')->format('Y-m-d');
		}
		while (isset($dateSet[$streakDate])) {
			$streak++;
			$streakDate = (new DateTimeImmutable($streakDate, new DateTimeZone('UTC')))->modify('-1 day')->format('Y-m-d');
		}

		foreach ($sessions as &$session) {
			$session['id'] = (int) $session['id'];
			$session['duration_minutes'] = (int) $session['duration_minutes'];
			$session['focus_level'] = (int) $session['focus_level'];
		}
		unset($session);

		send_json([
			'user' => [
				'id' => (int) $user['id'],
				'full_name' => $user['full_name'],
				'email' => $user['email'],
			],
			'csrf_token' => csrf_token(),
			'sessions' => $sessions,
			'summary' => [
				'weekly_minutes' => $weeklyMinutes,
				'weekly_goal_minutes' => 720,
				'day_minutes' => $dayMinutes,
				'subjects' => $subjectSummary,
				'session_count' => (int) $aggregate['session_count'],
				'focus_score' => $aggregate['average_focus'] === null ? null : (int) round((float) $aggregate['average_focus'] * 20),
				'streak_days' => $streak,
			],
		]);
	}

	if ($method === 'POST') {
		if (!verify_csrf_token($_SERVER['HTTP_X_CSRF_TOKEN'] ?? null)) {
			send_json(['error' => 'Your session expired. Reload the page and try again.'], 403);
		}

		$input = json_decode((string) file_get_contents('php://input'), true);
		if (!is_array($input)) {
			send_json(['error' => 'Send the study session as JSON.'], 400);
		}

		$subject = trim((string) ($input['subject'] ?? ''));
		$duration = filter_var($input['duration'] ?? null, FILTER_VALIDATE_INT);
		$focus = filter_var($input['focus'] ?? null, FILTER_VALIDATE_INT);
		$note = trim((string) ($input['note'] ?? ''));
		$allowedSubjects = ['Data Structures', 'Discrete Mathematics', 'Human-Computer Interaction', 'Other'];
		$noteLength = function_exists('mb_strlen') ? mb_strlen($note, 'UTF-8') : strlen($note);

		if (!in_array($subject, $allowedSubjects, true)) {
			send_json(['error' => 'Choose a subject from the list.'], 422);
		}
		if ($duration === false || $duration < 5 || $duration > 240) {
			send_json(['error' => 'Study duration must be between 5 and 240 minutes.'], 422);
		}
		if ($focus === false || $focus < 1 || $focus > 5) {
			send_json(['error' => 'Focus level must be between 1 and 5.'], 422);
		}
		if ($noteLength > 500) {
			send_json(['error' => 'Notes must be 500 characters or fewer.'], 422);
		}

		$insert = $pdo->prepare(
			'INSERT INTO study_sessions (owner_key, subject, duration_minutes, focus_level, note, studied_at)
			 VALUES (:owner_key, :subject, :duration, :focus, :note, UTC_TIMESTAMP())'
		);
		$insert->execute([
			'owner_key' => $ownerKey,
			'subject' => $subject,
			'duration' => $duration,
			'focus' => $focus,
			'note' => $note === '' ? null : $note,
		]);

		send_json(['success' => true, 'id' => (int) $pdo->lastInsertId()], 201);
	}

	header('Allow: GET, POST');
	send_json(['error' => 'Method not allowed.'], 405);
} catch (PDOException $exception) {
	database_error();
}
