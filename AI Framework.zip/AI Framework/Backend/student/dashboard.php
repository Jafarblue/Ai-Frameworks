<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_user_role('student');

header('Location: ' . app_url('index.php'));
exit;
