<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';

$user = authenticated_user();
if ($user !== null) {
	$destination = ($user['role'] ?? '') === 'admin' ? 'Backend/admin/dashboard.php' : 'index.php';
	header('Location: ' . app_url($destination));
	exit;
}

$error = '';
$flash = (string) ($_SESSION['auth_flash'] ?? '');
unset($_SESSION['auth_flash']);

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
	if (!verify_csrf_token($_POST['csrf_token'] ?? null)) {
		$error = 'Your session expired. Refresh this page and try again.';
	} else {
		$email = strtolower(trim((string) ($_POST['email'] ?? '')));
		$password = (string) ($_POST['password'] ?? '');

		if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
			$error = 'Enter a valid email address and password.';
		} else {
			try {
				$query = database()->prepare(
					'SELECT id, full_name, email, password_hash, role
					 FROM users WHERE email = :email LIMIT 1'
				);
				$query->execute(['email' => $email]);
				$account = $query->fetch();
			} catch (PDOException $exception) {
				database_error();
			}

			if ($account === false || !password_verify($password, $account['password_hash'])) {
				$error = 'Email or password is incorrect.';
			} else {
				session_regenerate_id(true);
				$_SESSION['user'] = [
					'id' => (int) $account['id'],
					'full_name' => $account['full_name'],
					'email' => $account['email'],
					'role' => $account['role'],
				];
				unset($_SESSION['csrf_token']);
				$destination = $account['role'] === 'admin' ? 'Backend/admin/dashboard.php' : 'index.php';
				header('Location: ' . app_url($destination));
				exit;
			}
		}
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="theme-color" content="#f6f7f2">
	<title>Sign in | Learnwise</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="<?= escape_html(app_url('CSS/auth.css')) ?>">
</head>
<body>
	<main class="auth-shell">
		<section class="auth-aside" aria-label="Learnwise student learning platform">
			<a class="auth-brand" href="<?= escape_html(app_url('')) ?>"><span class="brand-mark">L</span><span>learnwise<span class="brand-dot">.</span></span></a>
			<div class="aside-message"><span class="aside-kicker">STUDENT LEARNING INTELLIGENCE</span><h1>A clearer picture of how you learn.</h1><p>Build a steady study rhythm with insights shaped around your own habits.</p></div>
			<div class="aside-foot"><span>YOUR LEARNING, YOUR PACE</span><span class="aside-mark">✳</span></div>
		</section>
		<section class="auth-main">
			<div class="auth-form-wrap">
				<p class="auth-eyebrow">WELCOME BACK</p>
				<h2>Sign in to Learnwise</h2>
				<p class="auth-description">Continue to your student learning dashboard.</p>
				<?php if ($flash !== ''): ?><div class="auth-alert auth-success" role="status"><?= escape_html($flash) ?></div><?php endif; ?>
				<?php if ($error !== ''): ?><div class="auth-alert auth-error" role="alert"><?= escape_html($error) ?></div><?php endif; ?>
				<form method="post" action="<?= escape_html(app_url('Backend/login.php')) ?>" class="auth-form">
					<input type="hidden" name="csrf_token" value="<?= escape_html(csrf_token()) ?>">
					<label for="email">Email address</label>
					<input id="email" name="email" type="email" autocomplete="email" value="<?= escape_html((string) ($_POST['email'] ?? '')) ?>" required>
					<label for="password">Password</label>
					<input id="password" name="password" type="password" autocomplete="current-password" required>
					<button class="auth-submit" type="submit">Sign in <span aria-hidden="true">→</span></button>
				</form>
				<p class="auth-switch">New to Learnwise? <a href="<?= escape_html(app_url('Backend/register.php')) ?>">Create a student account</a></p>
				<p class="auth-privacy">Student and administrator accounts use the same sign-in form.</p>
			</div>
		</section>
	</main>
</body>
</html>
