<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST' || !verify_csrf_token($_POST['csrf_token'] ?? null)) {
	header('Location: ' . app_url('index.php'));
	exit;
}

$_SESSION = [];
session_regenerate_id(true);
header('Location: ' . app_url('Backend/login.php'));
exit;