<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
$admin = require_user_role('admin');
$studentCount = 0;
$sessionCount = 0;
$activeStudents = 0;
$studyMinutes = 0;
$students = [];

try {
	$pdo = database();
	$studentCount = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'student'")->fetchColumn();
	$sessionCount = (int) $pdo->query('SELECT COUNT(*) FROM study_sessions')->fetchColumn();
	$activeStudents = (int) $pdo->query('SELECT COUNT(DISTINCT owner_key) FROM study_sessions')->fetchColumn();
	$studyMinutes = (int) $pdo->query('SELECT COALESCE(SUM(duration_minutes), 0) FROM study_sessions')->fetchColumn();
	$students = $pdo->query(
		"SELECT id, full_name, email, created_at FROM users
		 WHERE role = 'student' ORDER BY created_at DESC LIMIT 100"
	)->fetchAll();
	$activityQuery = $pdo->prepare(
		'SELECT COUNT(*) AS session_count, COALESCE(SUM(duration_minutes), 0) AS study_minutes
		 FROM study_sessions WHERE owner_key = :owner_key'
	);
	foreach ($students as &$student) {
		$activityQuery->execute(['owner_key' => hash('sha256', 'learnwise-user-' . $student['id'])]);
		$activity = $activityQuery->fetch();
		$student['session_count'] = (int) $activity['session_count'];
		$student['study_minutes'] = (int) $activity['study_minutes'];
	}
	unset($student);
} catch (PDOException $exception) {
	database_error();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="theme-color" content="#f6f7f2">
	<title>Admin dashboard | Learnwise</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="<?= escape_html(app_url('CSS/auth.css')) ?>">
	<link rel="stylesheet" href="<?= escape_html(app_url('CSS/admin.css')) ?>">
	<script src="https://unpkg.com/lucide@latest" defer></script>
	<script defer>document.addEventListener('DOMContentLoaded', () => window.lucide?.createIcons());</script>
</head>
<body class="admin-body">
	<div class="admin-shell">
		<aside class="admin-sidebar">
			<a class="auth-brand" href="<?= escape_html(app_url('Backend/admin/dashboard.php')) ?>"><span class="brand-mark">L</span><span>learnwise<span class="brand-dot">.</span></span></a>
			<div class="admin-nav-title">ADMINISTRATION</div>
			<a class="admin-nav-link active" href="<?= escape_html(app_url('Backend/admin/dashboard.php')) ?>"><i data-lucide="layout-dashboard"></i>Overview</a>
			<a class="admin-nav-link" href="<?= escape_html(app_url('Backend/admin/dashboard.php#student-directory')) ?>"><i data-lucide="users"></i>Students</a>
			<div class="admin-sidebar-bottom">
				<div class="admin-profile"><span class="admin-avatar">AD</span><span><strong><?= escape_html($admin['full_name']) ?></strong><small>Administrator</small></span></div>
				<form method="post" action="<?= escape_html(app_url('Backend/logout.php')) ?>"><input type="hidden" name="csrf_token" value="<?= escape_html(csrf_token()) ?>"><button class="admin-logout" type="submit"><i data-lucide="log-out"></i>Sign out</button></form>
			</div>
		</aside>
		<main class="admin-main">
			<header class="admin-topbar"><span>Administration <i data-lucide="chevron-right"></i> Overview</span><span><?= escape_html(date('D, M j')) ?></span></header>
			<div class="admin-content">
				<div class="admin-heading"><div><p class="auth-eyebrow">LEARNWISE OPERATIONS</p><h1>Admin dashboard</h1><p>Overview of student accounts and study activity.</p></div><span class="admin-role-badge"><i data-lucide="shield-check"></i> ADMIN</span></div>
				<section class="admin-metrics" aria-label="Platform summary">
					<article><span>Total students <i data-lucide="users"></i></span><strong><?= number_format($studentCount) ?></strong><small>Registered student accounts</small></article>
					<article><span>Study sessions <i data-lucide="notebook-tabs"></i></span><strong><?= number_format($sessionCount) ?></strong><small>Sessions logged across the platform</small></article>
					<article><span>Active learners <i data-lucide="activity"></i></span><strong><?= number_format($activeStudents) ?></strong><small>Students with a logged session</small></article>
					<article><span>Study time <i data-lucide="clock-3"></i></span><strong><?= number_format(round($studyMinutes / 60, 1), 1) ?>h</strong><small>Total time recorded</small></article>
				</section>
				<section class="admin-table-panel" id="student-directory">
					<div class="admin-table-heading"><div><p class="auth-eyebrow">STUDENT DIRECTORY</p><h2>Student accounts</h2></div><span><?= number_format($studentCount) ?> total</span></div>
					<div class="admin-table-scroll"><table><thead><tr><th>STUDENT</th><th>EMAIL</th><th>SESSIONS</th><th>STUDY TIME</th><th>JOINED</th></tr></thead><tbody>
					<?php foreach ($students as $student): ?>
						<tr><td><strong><?= escape_html($student['full_name']) ?></strong></td><td><?= escape_html($student['email']) ?></td><td><?= number_format((int) $student['session_count']) ?></td><td><?= number_format(round((int) $student['study_minutes'] / 60, 1), 1) ?>h</td><td><?= escape_html(date('M j, Y', strtotime($student['created_at']))) ?></td></tr>
					<?php endforeach; ?>
					<?php if (!$students): ?><tr><td class="admin-empty" colspan="5">No student accounts yet. New registrations will appear here.</td></tr><?php endif; ?>
					</tbody></table></div>
				</section>
				<p class="admin-footnote"><i data-lucide="lock-keyhole"></i> Account details are visible only to signed-in administrators.</p>
			</div>
		</main>
	</div>
</body>
</html>
