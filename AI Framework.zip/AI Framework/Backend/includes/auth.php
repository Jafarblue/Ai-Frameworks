<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

function authenticated_user(): ?array
{
	$user = $_SESSION['user'] ?? null;
	return is_array($user) ? $user : null;
}

function csrf_token(): string
{
	if (!isset($_SESSION['csrf_token'])) {
		$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
	}

	return $_SESSION['csrf_token'];
}

function verify_csrf_token(mixed $token): bool
{
	return is_string($token)
		&& isset($_SESSION['csrf_token'])
		&& hash_equals($_SESSION['csrf_token'], $token);
}

function require_authenticated_user(bool $json = false): array
{
	$user = authenticated_user();
	if ($user !== null) {
		return $user;
	}

	if ($json) {
		send_json(['error' => 'Sign in to access your learning account.'], 401);
	}

	header('Location: ' . app_url('Backend/login.php'));
	exit;
}

function require_user_role(string $role): array
{
	$user = require_authenticated_user();
	if (($user['role'] ?? '') !== $role) {
		$destination = ($user['role'] ?? '') === 'admin'
			? 'Backend/admin/dashboard.php'
			: 'index.php';
		header('Location: ' . app_url($destination));
		exit;
	}

	return $user;
}

function escape_html(string $value): string
{
	return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}