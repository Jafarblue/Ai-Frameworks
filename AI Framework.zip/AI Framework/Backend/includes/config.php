<?php
declare(strict_types=1);

date_default_timezone_set('UTC');

if (session_status() !== PHP_SESSION_ACTIVE) {
	ini_set('session.use_strict_mode', '1');
	ini_set('session.gc_maxlifetime', '2592000');
	session_set_cookie_params([
		'lifetime' => 2592000,
		'path' => '/',
		'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
		'httponly' => true,
		'samesite' => 'Lax',
	]);
	session_start();
}

function database(): PDO
{
	static $connection = null;

	if ($connection instanceof PDO) {
		return $connection;
	}

	$host = getenv('DB_HOST') ?: '127.0.0.1';
	$name = getenv('DB_NAME') ?: 'student_ai';
	$user = getenv('DB_USER') ?: 'root';
	$password = getenv('DB_PASS') ?: '';

	$connection = new PDO(
		"mysql:host={$host};dbname={$name};charset=utf8mb4",
		$user,
		$password,
		[
			PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
			PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
			PDO::ATTR_EMULATE_PREPARES => false,
		]
	);

	return $connection;
}

function current_owner_key(): string
{
	$userId = $_SESSION['user']['id'] ?? null;
	$identity = $userId === null ? session_id() : 'learnwise-user-' . $userId;
	return hash('sha256', $identity);
}

function app_base_path(): string
{
	$scriptName = rawurldecode(str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? '/')));
	$backendPosition = strpos($scriptName, '/Backend/');
	$path = $backendPosition === false ? dirname($scriptName) : substr($scriptName, 0, $backendPosition);
	$segments = array_filter(explode('/', trim($path, '/')), static fn (string $segment): bool => $segment !== '');
	$encodedPath = implode('/', array_map('rawurlencode', $segments));

	return $encodedPath === '' ? '/' : '/' . $encodedPath . '/';
}

function app_url(string $path = ''): string
{
	return app_base_path() . ltrim($path, '/');
}

function send_json(array $payload, int $status = 200): void
{
	http_response_code($status);
	header('Content-Type: application/json; charset=utf-8');
	header('Cache-Control: no-store, private');
	echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	exit;
}

function database_error(): void
{
	error_log('Learnwise database connection or query failed.');
	send_json(['error' => 'The learning database is not available. Check the PHP database configuration.'], 503);
}
