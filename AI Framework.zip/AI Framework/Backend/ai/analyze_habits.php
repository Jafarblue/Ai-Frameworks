<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
$user = require_authenticated_user(true);
if (($user['role'] ?? '') !== 'student') {
	send_json(['error' => 'This endpoint is available to student accounts only.'], 403);
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
	header('Allow: GET');
	send_json(['error' => 'Method not allowed.'], 405);
}

try {
	$pdo = database();
	$ownerKey = current_owner_key();
	$since = (new DateTimeImmutable('now', new DateTimeZone('UTC')))->modify('-30 days')->format('Y-m-d H:i:s');

	$summaryQuery = $pdo->prepare(
		'SELECT COUNT(*) AS session_count, AVG(duration_minutes) AS average_duration,
				AVG(focus_level) AS average_focus
		 FROM study_sessions WHERE owner_key = :owner_key AND studied_at >= :since'
	);
	$summaryQuery->execute(['owner_key' => $ownerKey, 'since' => $since]);
	$summary = $summaryQuery->fetch();

	$subjectQuery = $pdo->prepare(
		'SELECT subject, COUNT(*) AS session_count, SUM(duration_minutes) AS total_minutes,
				AVG(focus_level) AS average_focus
		 FROM study_sessions
		 WHERE owner_key = :owner_key AND studied_at >= :since
		 GROUP BY subject ORDER BY total_minutes DESC LIMIT 1'
	);
	$subjectQuery->execute(['owner_key' => $ownerKey, 'since' => $since]);
	$topSubject = $subjectQuery->fetch() ?: null;

	$hourQuery = $pdo->prepare(
		'SELECT FLOOR(HOUR(studied_at) / 2) * 2 AS study_hour, COUNT(*) AS session_count,
				AVG(focus_level) AS average_focus
		 FROM study_sessions
		 WHERE owner_key = :owner_key AND studied_at >= :since
		 GROUP BY FLOOR(HOUR(studied_at) / 2) HAVING COUNT(*) >= 2
		 ORDER BY average_focus DESC, session_count DESC LIMIT 1'
	);
	$hourQuery->execute(['owner_key' => $ownerKey, 'since' => $since]);
	$bestHour = $hourQuery->fetch() ?: null;

	$focusByHourQuery = $pdo->prepare(
		'SELECT FLOOR(HOUR(studied_at) / 2) * 2 AS study_hour, COUNT(*) AS session_count,
				AVG(focus_level) AS average_focus
		 FROM study_sessions
		 WHERE owner_key = :owner_key AND studied_at >= :since
		 GROUP BY FLOOR(HOUR(studied_at) / 2)'
	);
	$focusByHourQuery->execute(['owner_key' => $ownerKey, 'since' => $since]);
	$focusByHour = [];
	foreach ($focusByHourQuery->fetchAll() as $row) {
		$focusByHour[(int) $row['study_hour']] = [
			'session_count' => (int) $row['session_count'],
			'focus_score' => (int) round((float) $row['average_focus'] * 20),
		];
	}

	$count = (int) $summary['session_count'];
	$recommendations = [];
	if ($bestHour !== null) {
		$hour = (int) $bestHour['study_hour'];
		$timeLabel = $hour === 0 ? '12 am' : ($hour < 12 ? $hour . ' am' : ($hour === 12 ? '12 pm' : ($hour - 12) . ' pm'));
		$nextHour = ($hour + 2) % 24;
		$nextLabel = $nextHour === 0 ? '12 am' : ($nextHour < 12 ? $nextHour . ' am' : ($nextHour === 12 ? '12 pm' : ($nextHour - 12) . ' pm'));
		$recommendations[] = [
			'title' => 'Plan demanding work during your strongest focus window',
			'description' => "Your focus ratings are strongest around {$timeLabel}. Try a challenging topic between {$timeLabel} and {$nextLabel}.",
			'subject' => $topSubject['subject'] ?? 'Your current subject',
			'duration' => 25,
			'reason' => (int) $bestHour['session_count'] . ' sessions logged in this time window',
		];
	}

	if ($topSubject !== null) {
		$recommendations[] = [
			'title' => 'Use active recall for ' . $topSubject['subject'],
			'description' => 'You have spent the most study time on this subject recently. A short self-test can help you check what is sticking.',
			'subject' => $topSubject['subject'],
			'duration' => 25,
			'reason' => (int) $topSubject['session_count'] . ' recent sessions in this subject',
		];
	}

	if (count($recommendations) < 2) {
		$recommendations[] = [
			'title' => 'Log a few more sessions to uncover your patterns',
			'description' => 'Add the subject, duration and focus level after each study session. Your habit insights will become more personal as you go.',
			'subject' => 'Any subject',
			'duration' => 25,
			'reason' => $count . ' sessions logged in the last 30 days',
		];
	}

	send_json([
		'session_count' => $count,
		'average_duration' => $summary['average_duration'] === null ? null : (int) round((float) $summary['average_duration']),
		'average_focus_score' => $summary['average_focus'] === null ? null : (int) round((float) $summary['average_focus'] * 20),
		'top_subject' => $topSubject['subject'] ?? null,
		'best_hour' => $bestHour === null ? null : (int) $bestHour['study_hour'],
		'focus_window_sessions' => $bestHour === null ? 0 : (int) $bestHour['session_count'],
		'focus_by_hour' => $focusByHour,
		'recommendations' => $recommendations,
	]);
} catch (PDOException $exception) {
	database_error();
}
