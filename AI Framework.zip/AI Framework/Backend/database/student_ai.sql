CREATE DATABASE IF NOT EXISTS student_ai
	CHARACTER SET utf8mb4
	COLLATE utf8mb4_unicode_ci;

USE student_ai;

CREATE TABLE IF NOT EXISTS users (
	id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
	full_name VARCHAR(120) NOT NULL,
	email VARCHAR(190) NOT NULL,
	password_hash VARCHAR(255) NOT NULL,
	role ENUM('student', 'admin') NOT NULL DEFAULT 'student',
	created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (id),
	UNIQUE KEY uq_users_email (email),
	KEY idx_users_role_created (role, created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS study_sessions (
	id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
	owner_key CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
	subject VARCHAR(100) NOT NULL,
	duration_minutes SMALLINT UNSIGNED NOT NULL,
	focus_level TINYINT UNSIGNED NOT NULL,
	note VARCHAR(500) NULL,
	studied_at DATETIME NOT NULL,
	created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (id),
	KEY idx_owner_studied_at (owner_key, studied_at),
	KEY idx_owner_subject (owner_key, subject),
	CONSTRAINT chk_study_duration CHECK (duration_minutes BETWEEN 5 AND 240),
	CONSTRAINT chk_study_focus CHECK (focus_level BETWEEN 1 AND 5)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS users (
	id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
	full_name VARCHAR(120) NOT NULL,
	email VARCHAR(190) NOT NULL,
	password_hash VARCHAR(255) NOT NULL,
	role ENUM('student', 'admin') NOT NULL DEFAULT 'student',
	created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (id),
	UNIQUE KEY uq_users_email (email),
	KEY idx_users_role_created (role, created_at)
) ENGINE=InnoDB;
