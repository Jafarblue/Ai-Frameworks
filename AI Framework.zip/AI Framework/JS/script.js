(() => {
	const views = [...document.querySelectorAll("[data-page]")];
	const navLinks = [...document.querySelectorAll("[data-view]")];
	const sidebar = document.querySelector("#sidebar");
	const modal = document.querySelector("#session-modal");
	const form = document.querySelector("#session-form");
	const toast = document.querySelector("#toast");
	const activitiesApi = "Backend/student/activities.php";
	const habitsApi = "Backend/ai/analyze_habits.php";
	let toastTimer;
	let csrfToken = "";

	const icons = () => window.lucide?.createIcons();
	const makeElement = (tag, className = "", text) => {
		const node = document.createElement(tag);
		if (className) node.className = className;
		if (text !== undefined) node.textContent = text;
		return node;
	};

	async function requestJson(url, options = {}) {
		const response = await fetch(url, {
			credentials: "same-origin",
			...options,
			headers: { Accept: "application/json", ...(options.headers || {}) },
		});
		let payload;
		try {
			payload = await response.json();
		} catch {
			throw new Error("The PHP server returned an invalid response.");
		}
		if (response.status === 401) {
			window.location.assign("Backend/login.php");
			throw new Error("Sign in again to continue.");
		}
		if (!response.ok) throw new Error(payload.error || "The request could not be completed.");
		return payload;
	}

	function showToast(message) {
		toast.textContent = message;
		toast.classList.add("visible");
		window.clearTimeout(toastTimer);
		toastTimer = window.setTimeout(() => toast.classList.remove("visible"), 3500);
	}

	function changeView(name) {
		views.forEach((view) => view.classList.toggle("active-view", view.dataset.page === name));
		navLinks.forEach((link) => link.classList.toggle("active", link.dataset.view === name));
		const activeLink = navLinks.find((link) => link.dataset.view === name);
		document.querySelector("#breadcrumb-current").textContent = activeLink?.querySelector("span")?.textContent || "Overview";
		sidebar.classList.remove("open");
		window.scrollTo({ top: 0, behavior: "smooth" });
	}

	function formatHour(hour) {
		return `${hour % 12 || 12} ${hour < 12 ? "am" : "pm"}`;
	}

	function formatDuration(minutes) {
		const hours = Math.floor(minutes / 60);
		const remaining = minutes % 60;
		if (!hours) return `${remaining}m`;
		return remaining ? `${hours}h ${remaining}m` : `${hours}h`;
	}

	function relativeDate(date) {
		const today = new Date();
		const local = (value) => new Date(value.getFullYear(), value.getMonth(), value.getDate());
		const daysAgo = Math.round((local(today) - local(date)) / 86400000);
		if (daysAgo === 0) return "Today";
		if (daysAgo === 1) return "Yesterday";
		return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
	}

	function openModal(recommendation = null) {
		modal.hidden = false;
		document.body.style.overflow = "hidden";
		if (recommendation) {
			const subject = form.elements.subject;
			if ([...subject.options].some((option) => option.value === recommendation.subject)) subject.value = recommendation.subject;
			form.elements.duration.value = String(recommendation.duration);
		}
		window.setTimeout(() => form.elements.subject.focus(), 20);
	}

	function closeModal() {
		modal.hidden = true;
		document.body.style.overflow = "";
	}

	function renderSubjects(subjects, totalMinutes) {
		const subjectList = document.querySelector("#subject-list");
		const breakdown = document.querySelector("#subject-breakdown");
		subjectList.replaceChildren();
		breakdown.replaceChildren();
		if (!subjects.length) {
			const emptyText = "Your subject breakdown will appear after you log a session.";
			subjectList.append(makeElement("p", "empty-data", emptyText));
			breakdown.append(makeElement("p", "empty-data", emptyText));
			return;
		}

		const palette = [
			{ badge: "subject-green", dot: "dot-green", color: "#3e8b6d" },
			{ badge: "subject-peach", dot: "dot-coral", color: "#de8468" },
			{ badge: "subject-yellow", dot: "dot-yellow", color: "#d3a642" },
		];
		subjects.forEach((subject, index) => {
			const style = palette[index % palette.length];
			const minutes = Number(subject.minutes) || 0;
			const percent = totalMinutes ? Math.round((minutes / totalMinutes) * 100) : 0;
			const initials = subject.subject.split(/\s+/).map((part) => part[0]).join("").slice(0, 2).toUpperCase();
			const row = makeElement("div", "subject-row");
			const badge = makeElement("span", `subject-symbol ${style.badge}`, initials);
			const details = makeElement("div", "subject-info");
			const labels = makeElement("div");
			labels.append(makeElement("strong", "", subject.subject), makeElement("span", "", formatDuration(minutes)));
			const track = makeElement("div", "subject-track");
			const fill = makeElement("i");
			fill.style.setProperty("--subject-width", `${percent}%`);
			fill.style.setProperty("--subject-color", style.color);
			track.append(fill);
			details.append(labels, track);
			row.append(badge, details, makeElement("span", "subject-percent", `${percent}%`));
			subjectList.append(row);

			const detailRow = makeElement("div");
			const detailTrack = makeElement("div", "breakdown-track");
			const detailFill = makeElement("i");
			detailFill.style.setProperty("--subject-width", `${percent}%`);
			detailFill.style.setProperty("--subject-color", style.color);
			detailTrack.append(detailFill);
			detailRow.append(makeElement("span", `breakdown-dot ${style.dot}`), makeElement("strong", "", subject.subject), detailTrack, makeElement("span", "", formatDuration(minutes)));
			breakdown.append(detailRow);
		});
	}

	function renderSummary(summary) {
		const weeklyMinutes = Number(summary.weekly_minutes) || 0;
		const goalMinutes = Number(summary.weekly_goal_minutes) || 720;
		const weeklyHours = (weeklyMinutes / 60).toFixed(1);
		const goalPercent = Math.min(Math.round((weeklyMinutes / goalMinutes) * 100), 100);
		const focusScore = summary.focus_score;
		const streak = Number(summary.streak_days) || 0;

		document.querySelector("#weekly-hours").textContent = weeklyHours;
		document.querySelector("#sidebar-hours").textContent = weeklyHours;
		document.querySelector("#goal-current").textContent = weeklyHours;
		document.querySelector("#goal-percent").textContent = `${goalPercent}%`;
		document.querySelector("#goal-ring").style.setProperty("--goal-angle", `${goalPercent * 3.6}deg`);
		document.querySelector("#sidebar-progress").style.width = `${goalPercent}%`;
		document.querySelector("#chart-hours").textContent = `${Math.floor(weeklyMinutes / 60)}h ${String(weeklyMinutes % 60).padStart(2, "0")}m`;
		document.querySelector("#focus-score").textContent = focusScore === null ? "—" : focusScore;
		document.querySelector("#focus-footnote").textContent = focusScore === null ? "Log sessions to build your focus score" : "Average of your session ratings";
		document.querySelector("#streak-days").textContent = streak;
		document.querySelector("#streak-footnote").textContent = streak === 0 ? "Log a session to start your streak" : streak === 1 ? "Your learning streak has started" : `${streak} consecutive study days`;
		document.querySelector("#goal-note").textContent = weeklyMinutes === 0 ? "Log a study session to begin your weekly goal." : goalPercent >= 100 ? "You reached your weekly study goal. Keep up your rhythm." : `${Math.ceil((goalMinutes - weeklyMinutes) / 60)} more study hours to reach your weekly goal.`;

		document.querySelectorAll("[data-study-bar]").forEach((bar, index) => {
			const minutes = Number(summary.day_minutes?.[index]) || 0;
			bar.style.setProperty("--bar-height", `${Math.max(3, Math.min((minutes / 240) * 100, 100))}%`);
			bar.classList.toggle("bar-empty", minutes === 0);
			document.querySelectorAll("[data-study-hours]")[index].textContent = `${(minutes / 60).toFixed(minutes % 60 === 0 ? 0 : 1)}h`;
		});
		renderSubjects(summary.subjects || [], weeklyMinutes);
	}

	function renderSessions(sessions, count) {
		const list = document.querySelector("#session-list");
		const emptyState = document.querySelector("#schedule-empty");
		list.replaceChildren();
		list.hidden = sessions.length === 0;
		emptyState.hidden = sessions.length > 0;
		document.querySelector("#planned-count-badge").textContent = `${count} ${count === 1 ? "session" : "sessions"}`;
		document.querySelector("#planned-session-summary").textContent = `${count} study ${count === 1 ? "session" : "sessions"} logged`;

		sessions.forEach((session) => {
			const date = new Date(`${session.studied_at.replace(" ", "T")}Z`);
			const color = session.subject === "Discrete Mathematics" ? "subject-peach" : session.subject === "Human-Computer Interaction" ? "subject-yellow" : "subject-green";
			const initials = session.subject.split(/\s+/).map((part) => part[0]).join("").slice(0, 2).toUpperCase();
			const row = makeElement("div", "session-row");
			const time = makeElement("div", "session-time");
			time.append(makeElement("strong", "", date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })), makeElement("span", "", `${session.duration_minutes} min · focus ${session.focus_level}/5`));
			const subject = makeElement("span", `session-subject-mark ${color}`, initials);
			const details = makeElement("div", "session-details");
			details.append(makeElement("strong", "", session.subject), makeElement("span", "", session.note || "Study session completed"));
			const status = makeElement("span", "icon-button session-more");
			status.setAttribute("aria-label", "Saved study session");
			const check = makeElement("i");
			check.setAttribute("data-lucide", "check");
			status.append(check);
			row.append(time, subject, details, makeElement("span", "session-day", relativeDate(date)), status);
			list.append(row);
		});
		icons();
	}

	function makeRecommendationCard(recommendation) {
		const card = makeElement("article", "recommendation-card");
		const icon = makeElement("div", "rec-icon rec-green");
		const iconImage = makeElement("i");
		iconImage.setAttribute("data-lucide", "sparkles");
		icon.append(iconImage);
		const body = makeElement("div", "rec-body");
		body.append(makeElement("span", "rec-tag", `${recommendation.subject} · ${recommendation.duration} MIN`.toUpperCase()), makeElement("h3", "", recommendation.title), makeElement("p", "", recommendation.description));
		const reason = makeElement("div", "rec-reason");
		const reasonIcon = makeElement("i");
		reasonIcon.setAttribute("data-lucide", "chart-no-axes-combined");
		reason.append(reasonIcon, document.createTextNode(recommendation.reason));
		body.append(reason);
		const action = makeElement("button", "round-arrow");
		action.type = "button";
		action.setAttribute("aria-label", "Start recommendation");
		const arrow = makeElement("i");
		arrow.setAttribute("data-lucide", "arrow-up-right");
		action.append(arrow);
		action.addEventListener("click", () => openModal(recommendation));
		card.append(icon, body, action);
		return card;
	}

	function renderRecommendations(recommendations) {
		const strip = document.querySelector("#recommendation-strip");
		const list = document.querySelector("#recommendation-list");
		strip.replaceChildren();
		list.replaceChildren();
		if (!recommendations.length) {
			strip.append(makeElement("p", "empty-data", "Personalized recommendations will appear as you log sessions."));
			list.append(makeElement("p", "empty-data", "Recommendations will be generated from your learning activity."));
			return;
		}
		const featured = recommendations[0];
		document.querySelector("#featured-rec-tag").textContent = `YOUR NEXT STEP · ${featured.duration} MIN`;
		document.querySelector("#featured-rec-title").textContent = featured.title;
		document.querySelector("#featured-rec-description").textContent = featured.description;
		document.querySelector("#featured-rec-duration").textContent = `${featured.duration} minutes`;
		document.querySelector("#featured-rec-subject").textContent = featured.subject;
		document.querySelector("#featured-rec-start").onclick = () => openModal(featured);
		recommendations.slice(0, 2).forEach((item) => strip.append(makeRecommendationCard(item)));
		recommendations.forEach((item) => list.append(makeRecommendationCard(item)));
		icons();
	}

	function renderAnalysis(analysis) {
		const bestHour = analysis.best_hour;
		const recommendation = analysis.recommendations?.[0];
		document.querySelector("#average-session").textContent = analysis.average_duration ?? "—";
		document.querySelector("#analysis-session-count").textContent = analysis.session_count ? `From ${analysis.session_count} recent sessions` : "No sessions analyzed yet";
		document.querySelector("#most-studied-subject").textContent = analysis.top_subject || "—";
		document.querySelector("#best-time-label").textContent = bestHour === null ? "—" : formatHour(bestHour);
		document.querySelector("#best-time-range").textContent = bestHour === null ? "" : `– ${formatHour((bestHour + 2) % 24)}`;
		document.querySelector("#best-time-caption").textContent = bestHour === null ? "Need more sessions in the same time window" : `Highest focus across ${analysis.focus_window_sessions} sessions`;
		document.querySelector("#focus-sample-count").textContent = analysis.session_count ? `Based on ${analysis.session_count} recent sessions` : "No data yet";
		document.querySelector("#insight-title").textContent = recommendation?.title || "Your study patterns will appear here.";
		document.querySelector("#insight-description").textContent = recommendation?.description || "Log a few sessions to get recommendations based on your own study activity.";
		document.querySelector("#habit-insight-title").textContent = bestHour === null ? "Your learning patterns will appear here." : "Your focus has a time-of-day pattern.";
		document.querySelector("#habit-insight-description").textContent = bestHour === null ? "Log sessions with focus ratings to reveal your strongest study habits." : `Your highest average focus rating was recorded around ${formatHour(bestHour)}. Try scheduling a challenging topic in this window.`;
		document.querySelector("#habit-insight-stat").textContent = analysis.average_focus_score === null ? "—" : `${analysis.average_focus_score}/100`;

		const chart = document.querySelector("#focus-time-bars");
		chart.replaceChildren();
		const hours = [8, 10, 12, 14, 16, 18];
		const scores = hours.map((hour) => Number(analysis.focus_by_hour?.[hour]?.focus_score) || 0);
		const maxScore = Math.max(...scores, 1);
		hours.forEach((hour, index) => {
			const column = makeElement("div");
			const bar = makeElement("i", scores[index] ? "" : "best-time");
			bar.style.setProperty("--time-height", `${Math.max(scores[index] ? 8 : 2, (scores[index] / maxScore) * 92)}%`);
			column.append(makeElement("span", "", formatHour(hour)), bar, makeElement("b", "", scores[index] ? String(scores[index]) : "—"));
			chart.append(column);
		});
		renderRecommendations(analysis.recommendations || []);
	}

	async function loadDashboard() {
		try {
			const [activity, analysis] = await Promise.all([requestJson(activitiesApi), requestJson(habitsApi)]);
			csrfToken = activity.csrf_token;
			const fullName = activity.user.full_name;
			document.querySelector("#student-name").textContent = fullName;
			document.querySelector("#student-first-name").textContent = fullName.trim().split(/\s+/)[0];
			document.querySelector("#student-email").textContent = activity.user.email;
			const initials = fullName.split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase();
			document.querySelector("#student-avatar").textContent = initials;
			document.querySelector("#student-top-avatar").textContent = initials;
			document.querySelector("#student-top-avatar").setAttribute("aria-label", `${fullName} profile`);
			document.querySelector("#logout-csrf").value = csrfToken;
			renderSummary(activity.summary);
			renderSessions(activity.sessions, activity.summary.session_count);
			renderAnalysis(analysis);
		} catch (error) {
			showToast(error.message || "Could not load your learning data.");
		}
	}

	function initializeCalendar(date) {
		document.querySelector("#greeting-eyebrow").textContent = `${date.toLocaleDateString("en-US", { weekday: "long" }).toUpperCase()}, YOUR MOMENTUM IS SHOWING`;
		const monday = new Date(date);
		monday.setDate(date.getDate() - ((date.getDay() + 6) % 7));
		document.querySelectorAll(".week-strip > div").forEach((cell, index) => {
			const day = new Date(monday);
			day.setDate(monday.getDate() + index);
			cell.querySelector("[data-weekday]").textContent = day.toLocaleDateString("en-US", { weekday: "short" }).toUpperCase();
			cell.querySelector("[data-date]").textContent = day.getDate();
			const isToday = day.toDateString() === date.toDateString();
			cell.classList.toggle("today", isToday);
			cell.querySelector("small").hidden = !isToday;
		});
	}

	navLinks.forEach((link) => link.addEventListener("click", () => changeView(link.dataset.view)));
	document.querySelectorAll("[data-go-view]").forEach((link) => link.addEventListener("click", () => changeView(link.dataset.goView)));
	document.querySelectorAll("[data-open-session]").forEach((button) => button.addEventListener("click", () => openModal()));
	document.querySelector("#menu-toggle").addEventListener("click", () => sidebar.classList.toggle("open"));
	document.querySelector("#close-modal").addEventListener("click", closeModal);
	document.querySelector("#cancel-modal").addEventListener("click", closeModal);
	modal.addEventListener("click", (event) => { if (event.target === modal) closeModal(); });
	document.addEventListener("keydown", (event) => { if (event.key === "Escape" && !modal.hidden) closeModal(); });
	document.querySelector("#notification-button").addEventListener("click", () => showToast("You're all caught up. Keep your learning streak going."));
	document.querySelector("#chart-period").addEventListener("click", () => showToast("Showing your study activity for this week."));
	document.querySelectorAll(".schedule-week-label button").forEach((button) => button.addEventListener("click", () => showToast("Your recent study record is shown below.")));

	form.addEventListener("submit", async (event) => {
		event.preventDefault();
		const formData = new FormData(form);
		const duration = Number(formData.get("duration"));
		const subject = String(formData.get("subject"));
		const submitButton = form.querySelector("[type=submit]");
		submitButton.disabled = true;
		try {
			await requestJson(activitiesApi, {
				method: "POST",
				headers: { "Content-Type": "application/json", "X-CSRF-Token": csrfToken },
				body: JSON.stringify({
					subject,
					duration,
					focus: Number(formData.get("focus")),
					note: String(formData.get("note")).trim(),
				}),
			});
			form.reset();
			closeModal();
			await loadDashboard();
			showToast(`${duration}-minute ${subject} session saved.`);
		} catch (error) {
			showToast(error.message || "Could not save your study session.");
		} finally {
			submitButton.disabled = false;
		}
	});

	const today = new Date();
	document.querySelector("#today-label").textContent = today.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
	initializeCalendar(today);
	icons();
	loadDashboard();
})();
