<?php
declare(strict_types=1);

require_once __DIR__ . '/Backend/includes/auth.php';

$user = authenticated_user();
if ($user === null) {
	header('Location: ' . app_url('Backend/login.php'));
	exit;
}

if (($user['role'] ?? '') === 'admin') {
	header('Location: ' . app_url('Backend/admin/dashboard.php'));
	exit;
}

header('Cache-Control: no-store, private');
$page = file_get_contents(__DIR__ . '/index.html');
$firstName = explode(' ', trim((string) $user['full_name']))[0];
$initials = implode('', array_map(static fn (string $part): string => substr($part, 0, 1), array_slice(preg_split('/\s+/', trim((string) $user['full_name'])) ?: [], 0, 2)));
$replacements = [
	'<input type="hidden" name="csrf_token" id="logout-csrf">' => '<input type="hidden" name="csrf_token" id="logout-csrf" value="' . escape_html(csrf_token()) . '">',
	'<span class="avatar" id="student-avatar">ST</span>' => '<span class="avatar" id="student-avatar">' . escape_html(strtoupper($initials)) . '</span>',
	'<strong id="student-name">Student</strong>' => '<strong id="student-name">' . escape_html((string) $user['full_name']) . '</strong>',
	'<small id="student-email">Student account</small>' => '<small id="student-email">' . escape_html((string) $user['email']) . '</small>',
	'<span id="student-first-name">student</span>' => '<span id="student-first-name">' . escape_html($firstName) . '</span>',
	'<button class="top-avatar" id="student-top-avatar" aria-label="Student profile">ST</button>' => '<button class="top-avatar" id="student-top-avatar" aria-label="' . escape_html((string) $user['full_name']) . ' profile">' . escape_html(strtoupper($initials)) . '</button>',
];
echo strtr($page === false ? '' : $page, $replacements);